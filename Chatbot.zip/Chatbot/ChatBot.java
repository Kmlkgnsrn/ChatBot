import okhttp3.*;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.Scanner;

public class ChatBot {
    private static final String API_KEY = "YOUR_OPENAI_API_KEY";
    private static final String API_URL = "https://api.openai.com/v1/completions";

    private final OkHttpClient httpClient;
    private final Gson gson;

    public ChatBot() {
        this.httpClient = new OkHttpClient();
        this.gson = new Gson();
    }

    public String getResponse(String prompt) throws IOException {
        prompt = preprocessUserInput(prompt);

        RequestBody body = RequestBody.create(
            gson.toJson(new OpenAIRequest(prompt)),
            MediaType.get("application/json; charset=utf-8")
        );

        Request request = new Request.Builder()
            .url(API_URL)
            .header("Authorization", "Bearer " + API_KEY)
            .post(body)
            .build();

        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }
            OpenAIResponse openAIResponse = gson.fromJson(response.body().string(), OpenAIResponse.class);
            return openAIResponse.getChoices().get(0).getText().trim();
        }
    }

    private String preprocessUserInput(String input) {
        return input.trim().toLowerCase();
    }

    private static class OpenAIRequest {
        private final String model = "text-davinci-003";
        private final String prompt;
        private final int max_tokens = 150;

        public OpenAIRequest(String prompt) {
            this.prompt = prompt;
        }
    }

    private static class OpenAIResponse {
        private List<Choice> choices;

        public List<Choice> getChoices() {
            return choices;
        }

        private static class Choice {
            private String text;

            public String getText() {
                return text;
            }
        }
    }

    public static void main(String[] args) {
        ChatBot chatBot = new ChatBot();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Chat bot'a hoş geldiniz! Çıkmak için 'çık' yazın.");

        while (true) {
            System.out.print("Siz: ");
            String userInput = scanner.nextLine();

            if (userInput.equalsIgnoreCase("çık")) {
                break;
            }

            try {
                String response = chatBot.getResponse(userInput);
                System.out.println("ChatGPT: " + response);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        scanner.close();
        System.out.println("Görüşmek üzere!");
    }
}
